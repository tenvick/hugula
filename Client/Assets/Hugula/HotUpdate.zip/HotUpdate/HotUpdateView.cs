﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Hugula.HotUpdate {
    public class HotUpdateView : MonoBehaviour {

        public Text tips;

        public Slider slider;

    }
}