﻿// Copyright (c) 2015 hugula
// direct https://github.com/tenvick/hugula
//
using UnityEngine;
using System.Collections;

namespace Hugula
{
    /// <summary>
    /// 给editor使用 用来查看引用数量
    /// </summary>
    public class ReferenceCountInfo : MonoBehaviour
    {
        public string info;
    }
}